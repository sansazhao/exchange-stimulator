#include <array>
#include <iostream>
#include <boost/array.hpp>
#include <boost/asio.hpp>
#include <string>
#include <fstream>
#include "Fix.h"
using boost::asio::ip::tcp;
using namespace std;

/*client port*/
/*connect to the server and communicate with the server with fix message
*the client need to input the name as soon as he connect to the server
*in each cycle :input 1: to send a new Fix message
*				input 2: to check his own orderBook
*				input 0: quit the simulator
*/


/*function: outputBook
*usage:output the client's own orderBook after inputing the number  2
*/
void outputBook() {
	fstream buyB;
	fstream sellB;
	string line;
	buyB.open("BuyOrder.txt");
	sellB.open("SellOrder.txt");
	if (!buyB)
		cout << "Not Buy order exists."<<endl;
	else {
		cout << "\t\t\tBUY ORDER\n"<<"OrderId\t\t"
		<< "ShareName\t" << "OrderQty\t"
			<< "Price\t\t"<<"LeftQty\t\t"<<"Time\n";
		while (getline(buyB, line))
			cout << line << endl;
	}
	if (!sellB)
		cout << "Not Sell order exists." << endl;
	else {
		cout << "\t\t\tSELL ORDER\n" << "OrderId\t\t"
			<< "ShareName\t"  << "OrderQty\t" 
			<< "Price\t\t"<<"LeftQty\t\t"<< "Time\n";
		while (getline(sellB, line))
			cout << line << endl;
	}
	buyB.close();
	sellB.close();
}


/*function:withinTime
* Homework5:Trading Client cannot send out orders outside the trading session.
*/
bool withinTime() {
	SYSTEMTIME st = { 0 };
	GetLocalTime(&st);
	stringstream s;
	s << st.wHour << ":" << st.wMinute << ":" << st.wSecond;
	string time = s.str();
	if (time>="9:30" && time <= "11:30")//can change the time 
		return true;
	return false;
}


/*main program:build the port and process the input cycle*/
int main(int argc, char* argv[])
{
	boost::asio::io_service io_service;
	tcp::resolver resolver(io_service);
	tcp::resolver::query query("127.0.0.1", "9876");
	tcp::resolver::iterator endpoint_iterator = resolver.resolve(query);
	tcp::socket socket(io_service);
	boost::asio::connect(socket, endpoint_iterator);
	boost::system::error_code error;
	cout << "What's your name?";
	string my_name;
	getline(cin, my_name);
	boost::asio::write(socket, boost::asio::buffer(my_name), error);
	while (1) {
		cout << "input 1:send a new Fix\n"
			 << "input 2:check your orders\n"
			 << "input 0:quit\n";
		int req;
		cin >> req;
		if (req == 1) {
			string Fix_;
			cin >> Fix_;
			Fix f(Fix_);
			if (f.valid()&&withinTime()) {
				//check the validity of Fix message before sending to the server
				boost::asio::write(socket, boost::asio::buffer(Fix_), error);
				array<char, 256> input_buffer;
				size_t rsize = socket.read_some(
					boost::asio::buffer(input_buffer), error);
				string returnFix(input_buffer.data(), input_buffer.data() + rsize);
				cout << returnFix << endl;
			}
			else if(!withinTime())
				cout << "Outside the trading session." << endl;
			else
				cout << "Invalid input" << endl;
		}
		else if (req == 2)
			outputBook();
		else if (req == 0)
			exit(0);
		else
			cout << "Invalid input"<<endl;
	}
	system("pause");
	return 0;
}
