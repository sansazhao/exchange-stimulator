#include"Fix.h"

set<int> all_tags =
   {8,150,39,35,54,38,55,6,11,41,40,14,44,151,40,105,10,8,9,34,52,0};


/*constructor:Fix(string fix)
*read the tags into a map ,check its validity and renew the orderbook
*/
Fix::Fix(string Fix) {
	set<int>all_fixTags;
	map<int, string> Fix_m;
	map<int, string>::iterator Fix_f;
	this->fixMap = Fix_m;
	this->f = Fix_f;
	this->whether_valid = true;
	int count = 0;
	for (char i : Fix)
		if (i = '=')
			count++;
	for (int i = 0; i < count; ++i) {
		int key = atoi(Fix.substr(0, Fix.find("=")).c_str());
		string value = Fix.substr
		(Fix.find("=") + 1, Fix.find(";") - Fix.find("=") - 1);
		int s = Fix.find(";") + 1;
		Fix = Fix.substr(s, Fix.find(";") - s - 1);
		fixMap[key] = value;
	}

	/*following cycles and judgements can check whether the 
	 * fix message is valid in most situations 
	 */
	for (f = fixMap.begin(); f != fixMap.end(); ++f) {
		string s = f->second;
		if (s == ""&&f->first != 0) {
			whether_valid = false;
			break;
		}
		if (all_tags.count(f->first) == 0) {
			whether_valid = false;
			break;
		}
		if (f->first == 39 || f->first == 150) {
			if (!(s == "0" || s == "1" || s == "2" || s == "4" || s == "8")) 
				whether_valid = false;
		}
		if (f->first == 35) {
			if (!(s == "8" || s == "9" || s == "D" || s == "F")) 
				whether_valid = false;
		}
		if (f->first == 54) {
			if (!(s == "0" || s == "1")) 
				whether_valid = false;
		}
	}
	for (char a : Fix)
		if (a == ';')
			whether_valid = false;
	if (whether_valid)
		renewBook();
}

/*implemention:renewBook
* separate the buyorders and sellorders,renew the buyOrderBook and
* the sellOrderBook after accept a new Fix message
*/
void Fix::renewBook() {
	if (fixMap[side] == (buy)) {
		fstream buyB;
		buyB.open("BuyOrder.txt",ios::app|ios::out);
		if (!buyB)
			cout << "fail to open buyBook";
		buyB <<fixMap[orderId] << "\t\t"
			<< fixMap[shareName] << "\t\t" << fixMap[orderQty] << "\t\t"
			<< fixMap[price] << "\t\t" << fixMap[leaveQty] <<"\t\t"
			<<fixMap[time]<< "\n";
		buyB.close();
	}
	if (fixMap[side] == (sell)) {
		fstream sellB;
		sellB.open("SellOrder.txt",ios::app|ios::out);
		if (!sellB)
			cout << "fail to open sellBook";
		sellB <<fixMap[orderId] << "\t\t"
			<< fixMap[shareName] << "\t\t" << fixMap[orderQty] << "\t\t"
			<< fixMap[price] << "\t\t" << fixMap[leaveQty] << "\t\t"
			<< fixMap[time] << "\n";
		sellB.close();
	}
}

