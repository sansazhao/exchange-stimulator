
#ifndef Fix_h
#define Fix_h


#include <string>
#include <sstream>
#include <fstream>
#include <iostream>
#include <set>
#include <map>

using namespace std;

class Fix {
public:

	/*constructor:Fix(string Fix)
	*after accepting a new Fix message from client,read the tags into a map,
	*check its validity and renew the orderbook
	*/
	Fix(string Fix);
	Fix() {}



	/*function:renewBook
	* usage:called in constructor Fix(string),renew the orderBook after
	* accepting a new Fix message
	*/
	void renewBook();


	/* function: tag()
     * return the map(tagKey-value)of the input fix message 
     */
	map<int, string> tag()
	{
		return fixMap;
	}


	bool valid() 
	{
		return whether_valid;
	}
	
	/*all fix tags and their meanings*/
	//defined as const int to increase the readability of the code

	/*tag 39*/
	const int ordStatus = 39;
	const int exeType = 150;

	const int New = 0;
	const int partial = 1;
	const int full = 2;
	const int canceled = 4;
	const int reject = 8;

	/*tag 35*/
	const int type = 35;
	const int ok = 8;
	const string start = "D";
	const string fail = "F";

	/*tag 54*/
	const int side = 54;
	const string buy = "1";
	const string sell = "0";

	/*tag 38*/
	const int orderQty = 38;

	/*tag 55*/
	const int shareName = 55;

	/*tag 6 average price of fills*/
	const int apf = 6;

	/*tag 11*/
	const int orderId = 11;

	/*tag 41 */
	const int cancelId = 41;

	/*tag 40*/
	const int orderType = 40;
	const int market = 1;
	const int limit = 2;

	/*tag 14*/
	const int cumQty = 14;

	/*tag 44*/
	const int price = 44;

	/*tag 151*/
	const int getLeft = 151;

	/*tag 52*/
	const int time = 52;


private:
	map<int, string> fixMap;
	//to store a fix message in a map 
	map<int, string>::iterator f;
	//the iterator of the map 
	bool whether_valid;
	//the mark to show whether the accepted fix is valid 



};

#endif 
