#include <array>
#include <iostream>
#include <string>
#include <map>
#include "order.h"
#include "Fix.h"
#include <ctime>
#include <boost/asio.hpp>
#include <vector>

using boost::asio::ip::tcp;
using namespace std;


/*some global variable:
* define class Fix and class order,save orders in vectors 
*/
enum orderType {_buy,_sell};
vector<order>buyOrd;
vector<order>sellOrd;
order to_attach;
order current;
int orderPos=0;
const string err = "Invalid Fix";
bool can_cancel = true;


/*function:getBook
* usage:save the order information in the files into a vector
* later we will search the vector and find the according order
*/
void getBook(vector<order>& b,vector<order>&s) {
	ifstream buy,sell;
	buy.open("BuyOrder.txt");
	sell.open("SellOrder.txt");
	if (!sell||!buy)
		cout << "fail";
	string line;
	stringstream ss;
	string id, name,time;
	int qty, left, status;
	double price;
	while (getline(sell,line)) {
		ss.str(line.c_str());
		ss >> id >> name >> qty >> price >> left >> status>>time;
		ss.clear();
		order ord(id, name, qty, left, price, status,time);
		s.push_back(ord);
	}
	while (getline(buy, line)) {
		ss.str(line.c_str());
		ss >> id >> name >> qty >> price >> left >> status>>time;
		ss.clear();
		order ord(id, name, qty, left, price, status,time);
		b.push_back(ord);
	}
	sell.close();
	buy.close();
}


/*function:renewBook
* usage:renew OrderBook according to the change vector
*/
void renewBook(vector<order>& b, vector<order>&s) {
	ofstream buy, sell;
	buy.open("BuyOrder.txt", ios::out|ios::ate);
	sell.open("SellOrder.txt", ios::out|ios::ate);
	if (!sell || !buy)
		cout << "fail";
	string line;
	stringstream ss;
	string id, name;
	int qty, left, status;
	double price;
	for (order ord : b) {
		buy<<ord.getId()<< "\t\t"
			<< ord.getName() << "\t\t" << ord.getQty() << "\t\t"
			<< ord.getPrice()<< "\t\t" << ord.getLeft() << "\t\t"
			<< ord.getSta()<<"\t\t"<< ord.getTime() << "\n";
	}
	for (order ord : s) {
		sell << ord.getId() << "\t\t"
			<< ord.getName() << "\t\t" << ord.getQty() << "\t\t"
			<< ord.getPrice() << "\t\t" << ord.getLeft() << "\t\t"
			<< ord.getSta() << "\t\t" << ord.getTime() << "\n";
	}
	sell.close();
	buy.close();
}


/*function:attachSellOrd
* usage:if the client is a buyer,match the new order with the existing orders
* if the order can be attached,the referred order "attach" is the according sellOrder
*/
bool attachSellOrd(order& cur,order& attach,vector<order>&vec) {
	for (int i = 0; i < vec.size(); ++i) {
		attach = vec[i];
		if (attach.getName() == cur.getName() 
			 && attach.getLeft() > 0 && cur.getPrice() >= attach.getPrice()
			&& attach.getSta() != 4) {
			//ensure the same shareName, enough quantity and proper finalprice
			orderPos = i;
			return true;
		}
	}
	return false;
}


/*function:attachBuyOrd
* usage:if the client is a seller,match the new order with the existing orders
* if the order can be attached,the referred order "attach" is the according buyOrder
*/
bool attachBuyOrd(order& cur, order& attach, vector<order>&vec) {
	for (int i = 0; i < vec.size(); ++i) {
		attach = vec[i];
		if (attach.getName() == cur.getName()
			&& attach.getLeft() > 0 && cur.getPrice()<=attach.getPrice()
			&&attach.getSta()!= 4) {
			//ensure the same shareName, enough quantity and proper finalprice
			orderPos = i;
			return true;
		}
	}
	return false;
}


/*function:processFill
* usage: change the quantity and price of the filled order
*/
void processFill(order& buy, order&sell, orderType kind, Fix f) {
	if (buy.getLeft() > sell.getLeft()) {
		int to_buy = sell.getLeft();
		buy.setLeaveQty(buy.getLeft() - to_buy);
		sell.setLeaveQty(0);
	}
	else {
		//if (buy.getLeft() <= sell.getLeft()) {
		int to_buy = buy.getLeft();
		buy.setLeaveQty(0);
		buy.setPrice(sell.getPrice());
		sell.setLeaveQty(sell.getLeft() - to_buy);
	}
	sell.setSta(f, 'D');
	buy.setSta(f, 'D');
	buy.setSucPrice(sell.getPrice());
	if (kind == _buy)
		buyOrd[orderPos] = buy;
	else
		sellOrd[orderPos] = sell;
}


/*function:cancelBuyOrd��cancelSellOrd��processCancel
* usage: cancel a old order 
*/
bool cancelBuyOrd(order& cur, order&attach, vector<order>&vec) {
	for (int i = 0; i < vec.size(); ++i) {
		attach = vec[i];
		if (attach.getId() == cur.getId() && attach.getSta() != 4) {
			orderPos = i;
			return true;
		}
	}
	return false;
}

bool cancelSellOrd(order& cur, order&attach, vector<order>&vec) {
	for (int i = 0; i < vec.size(); ++i) {
		attach = vec[i];
		if (attach.getId() == cur.getId() && attach.getSta() != 4) {
			orderPos = i;
			return true;
		}
	}
	return false;
}

void processCancel(vector<order>&vec,Fix f) {
	vec[orderPos].setSta(f,'F');
}


/*function: itos(int) and dtos(double)
* usage: transform the int/double into string 
*/
string itos(int a) {
	stringstream s;
	s << a;
	return s.str();
}

string dtos(double a) {
	stringstream s;
	s << a;
	return s.str();
}


/*function:withinTime
* usage:Homework5:Exchange Server can reject the incoming new orders
*       immediately outside the trading session.
*/
bool withinTime() {
	SYSTEMTIME st = { 0 };
	GetLocalTime(&st);
	stringstream s;
	s << st.wHour << ":" << st.wMinute << ":" << st.wSecond;
	string time = s.str();
	if ( time>"9:30" && time < "11:30")//can change the time 
		return true;
	return false;
}


/*function:ans_to
* usage: generate the message returned to the exchange client
*/
string ans_to(Fix f,order & cur) {
	map<int, string>tag = f.tag();
	string ans = "";
	string ack = "35=8;150=0;39=0\n";
	if (tag[35] == "D") {
		ans += ack;
		if (cur.getSta() == 1) {
			//partial fill
			ans += "35=8;150=1;39=1;11=" + cur.getId() + ";38=" + itos(cur.getQty())
				+ ";44=" + dtos(cur.getPrice()) + ";55=" + cur.getName()
				+ ";151=" + itos(cur.getLeft());
		}
		else if (cur.getSta()==2) {
			//full fill
			ans += "35=8;150=2;39=2;11=" + cur.getId() + ";38=" + itos(cur.getQty())
				+ ";44=" + dtos(cur.getPrice()) + ";55=" + cur.getName();
		}
		else if (cur.getSta()==0);
		else
			return err;
	}
	else {
		//(tag[35] == "F") {
		if (tag[41] == "" || can_cancel == false)
			return "35=9;39=8;";
		ans += "35=8;150=4;39=4;41="+tag[41];
	}
	return ans;
}


/*function:processFix
* usage:attach the needed order for the current order 
*        and decide the status of fill(full/partial)
*/
void processFix(Fix f) {
	if (f.tag()[f.type] == "D") {
		current =order(f);
		if (f.tag()[f.side] == f.buy)
		{
			while(current.getLeft()>0 
			    	&& attachSellOrd(current, to_attach, sellOrd))
				processFill(current, to_attach, _sell, f);
			buyOrd.push_back(current);
		}
		else
		{//if (f.tag()[f.side] == f.sell) 
			while (current.getLeft()>0 
				    && attachBuyOrd(current, to_attach, buyOrd))
				processFill(to_attach, current, _buy, f);
			sellOrd.push_back(current);
		}
		renewBook(buyOrd, sellOrd);
	}
	else if (f.tag()[f.type] == "F") {
		if (f.tag().count(41) == 0) {
			can_cancel = false;
			return;
		}
		else {
			current = order(f.tag()[41]);
			if (cancelSellOrd(current, to_attach, sellOrd))
				processCancel(sellOrd, f);
			else if (cancelBuyOrd(current, to_attach, buyOrd))
				processCancel(buyOrd, f);
			else
				can_cancel = false;
			renewBook(buyOrd, sellOrd);
		}
	}
	else
		;
}


/*function:restart
* usage: clean all old and useless information to get ready for new fix message
*/
void restart() {
	can_cancel = true;
	buyOrd.clear();
	sellOrd.clear();
	getBook(buyOrd, sellOrd);
}


/*function:to_monitor
* usage: generate the message returned to the monitoring client
*/
void to_monitor(string &ans,Fix f,order& current) {
	if (current.getSta() == 0)
		ans = "A new order: "+f.tag()[f.orderId]
			+ " has been inserted in the order book.\n";
	if (current.getSta() == 1)
		ans +=( "\nThe order: "+f.tag()[f.orderId] 
			+ "has been partial filled.\n");
	if (current.getSta() == 2)
		ans += ("\nThe order: " + f.tag()[f.orderId] 
			+ "has been fully filled.\n");
	if (f.tag()[35]=="F"&&can_cancel==true)
		ans += ("Order: " + f.tag()[f.cancelId] 
			+ "has been canceled successfully.\n");
	ans = ans+ "\t\t\tBUY ORDER\nOrderId\t\t"+
		"ShareName\tOrderQty\tPrice\tLeft\tStatus\tTime\n";
	for (order ord : buyOrd) {
		ans += (ord.getId()+"\t\t"+ord.getName()+ "\t\t"
			+ itos(ord.getQty())+"\t\t"
			+ dtos(ord.getPrice()) + "\t" 
			+ itos(ord.getLeft()) + "\t"
			+ itos( ord.getSta()) + "\t" 
			+ ord.getTime() + "\n");
	}
	ans = ans+ "\t\t\tSELL ORDER\nOrderId\t\t"+
		"ShareName\tOrderQty\tPrice\tLeft\tStatus\tTime\n";
	for (order ord : sellOrd) {
		ans += (ord.getId() + "\t\t" + ord.getName() + "\t\t" 
			+ itos(ord.getQty()) + "\t\t"
			+ dtos(ord.getPrice()) + "\t" 
			+ itos(ord.getLeft()) + "\t"
			+ itos(ord.getSta()) + "\t"
			+ ord.getTime() + "\n");
	}
}




/*main program: build the port to ine exchange client and one moniroring client

*   to exchange client: accept and send the fix continuously

*   to monitoring client: everytime a order status changes
*                         return the message and the new orderBook
*/

int main()
{
	getBook(buyOrd, sellOrd);
	boost::asio::io_service io_service;
	tcp::acceptor acc(io_service, tcp::endpoint(tcp::v6(), 9876));
	tcp::acceptor monitor(io_service, tcp::endpoint(tcp::v6(), 1234));
	while (1) {
		boost::system::error_code ignored;
		tcp::socket socket(io_service);
		acc.accept(socket);
		tcp::socket socket2(io_service);
		monitor.accept(socket2);
		std::array<char, 256> input_buffer;
		std::size_t input_size = socket.read_some(
				boost::asio::buffer(input_buffer),
				ignored);
		std::string visitor(input_buffer.data(),
				input_buffer.data() + input_size);
		std::cout << "Visited from " +
			socket.remote_endpoint().address().to_string() +
			" by client: " << visitor << std::endl;
		while (1) {
			{
				input_size = socket.read_some(boost::asio::buffer(input_buffer), ignored);
				if (!withinTime()) {
					boost::asio::write(socket,
						boost::asio::buffer("35 = 9;39 = 8;"), ignored);
					continue;
				}
				string F(input_buffer.data(),
					input_buffer.data() + input_size);
				Fix fix(F);
				processFix(fix);
				string ans = ans_to(fix, current);
				boost::asio::write(socket, boost::asio::buffer(ans), ignored);
				restart();
				//return message to monitoring client
				string ans_to_monitor="";
				to_monitor(ans_to_monitor,fix,current);
				boost::asio::write(socket2, boost::asio::buffer(ans_to_monitor), ignored);
			}
		}
		socket.shutdown(tcp::socket::shutdown_both, ignored);
		socket.close();
		socket2.shutdown(tcp::socket::shutdown_both, ignored);
		socket2.close();
	}
	return 0;
}
