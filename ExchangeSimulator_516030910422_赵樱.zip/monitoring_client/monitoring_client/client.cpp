#include <array>
#include <iostream>
#include <boost/array.hpp>
#include <boost/asio.hpp>
#include <string>
#include <fstream>

using boost::asio::ip::tcp;
using namespace std;

/*monitoring client*/
//connect to the server ,accept the message and orderbook everytime 
//when the client input a new fix to the server  
int main(int argc, char* argv[])
{
	boost::asio::io_service io_service;
	tcp::resolver resolver(io_service);
	tcp::resolver::query query("127.0.0.1", "1234");
	tcp::resolver::iterator endpoint_iterator = resolver.resolve(query);
	tcp::socket socket(io_service);
	boost::asio::connect(socket, endpoint_iterator);
	boost::system::error_code error;
	while (1) {
		array<char, 256> input_buffer;
		size_t rsize = socket.read_some(
			boost::asio::buffer(input_buffer), error);
		string returnAns(input_buffer.data(), input_buffer.data() + rsize);
		cout << returnAns << endl;
	}
	system("pause");
	return 0;
}
