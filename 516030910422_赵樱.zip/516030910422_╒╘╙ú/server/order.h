
#ifndef order_h
#define order_h

#include <string>
#include <sstream>
#include <fstream>
#include <boost/asio.hpp>
#include "time.h"
#include "Fix.h"

using namespace std;


class order {
public:	
	//default constructor: construct an empty order
	order();

	//constructor : construct a detailed order 
	order(string id, string name, int qty, int left,
		double price, int status, string time);

	//constructor : construct a order with only orderid
	//usage:used when we need to cancel an order
	order(string id) {
		this->id = id;
	}

	//constructor : construct a order with the fix message
	order(Fix f);

	string getName() {
		return name;
	}

	string getId() {
		return id;
	}


	int getQty() {
		return quantity;
	}

	double getPrice() {
		return price;
	}

	double getSuc_Price() {
		return price;
	}

	int getLeft() {
		return left;
	}


	int getSta() {
		return ordStatus;
	}

	double getValue() {
		double value = quantity*price;
		return value;
	}

	string getTime() {
		return _time;
	}

	string time() ;


	void setPrice(double p) {
		price = p;
	}

	void setSucPrice(double p) {
		lastSucPrice = p;
	}

	void setSta(Fix f, char kind);

	void setLeaveQty(int left) {
		this->left = left;
	}

private:
	string id;
	string name;
	string _time;
	int quantity;
	int left;
	double price;
	double lastSucPrice;
	int ordStatus;
};


#endif 
