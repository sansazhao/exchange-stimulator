#include"order.h"
#include <iostream>
#include <ctime>
#include<vector>
using namespace std;

order::order(){
	this->id = "";
	this->left = 0;
	this->ordStatus = 0;
	this->price = 0;
	this->quantity = 0;
}

order::order(string id, string name, int qty, int left, 
	double price, int status, string time) {
	this->id = id;
	this->name = name;
	this->left = left;
	this->ordStatus = status;
	this->price = price;
	this->quantity = qty;
	this->_time = time;
}


order::order(Fix f) {
	int qty = atoi(f.tag()[f.orderQty].c_str());
	double price = atof(f.tag()[f.price].c_str());
	int status = atoi(f.tag()[f.ordStatus].c_str());

	this->id = f.tag()[f.orderId];
	this->name = f.tag()[f.shareName];
	this->left = qty;
	this->ordStatus = status;
	this->price = price;
	this->quantity = qty;
	this->_time =f.tag()[f.time];

}


void order::setSta(Fix f, char kind) {
	if (kind == 'D') {
		if (left > 0) {
			this->ordStatus = 1;
			f.tag()[f.ordStatus] = "1";
		}

		else if (left == 0) {
			this->ordStatus = 2;
			f.tag()[f.ordStatus] = "2";
		}
	}
	else { //if(kind=='F')
		this->ordStatus = 4;
		f.tag()[f.ordStatus] = "4";
	}
}

string order::time() {
	SYSTEMTIME st = { 0 };
	GetLocalTime(&st);
	stringstream s;
	s << st.wYear << "-" << st.wMonth << "-" << st.wDay << "-"
		<< st.wHour << ":" << st.wMinute << ":" << st.wSecond;
	string time = s.str();
	return time;
}