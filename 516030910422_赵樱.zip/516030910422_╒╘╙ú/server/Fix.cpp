#include"Fix.h"

set<int> all_tags = { 150,39,35,54,38,55,6,11,41,40,14,44,151,40,105,10,8,9,34,
52,};


/*constructor:Fix(string fix)
*read the tags into a map ,check its validity and renew the orderbook
*/
Fix::Fix(string Fix) {
	set<int>all_fixTags;
	map<int, string> Fix_m;
	map<int, string>::iterator Fix_f;
	this->fixMap = Fix_m;
	this->f = Fix_f;
	this->whether_valid = true;
	int count = 0;
	for (char i : Fix)
		if (i = '=')count++;
	for (int i = 0; i < count; ++i) {
		int key = atoi(Fix.substr(0, Fix.find("=")).c_str());
		string value = Fix.substr
		             (Fix.find("=") + 1, Fix.find(";") - Fix.find("=") - 1);
		int s = Fix.find(";") + 1;
		Fix = Fix.substr(s, Fix.find(";") - s - 1);
		if (value == "" || all_tags.count(key) == 0) {
			whether_valid = false;
			break;
		}
		fixMap[key] = value;
	}
}


/*implemention:renewBook
 * separate the buyorders and sellorders,renew the buyOrderBook and 
 * the sellOrderBook after accept a new Fix message 
 */
void Fix::renewBook() {
	if (fixMap[side] == (buy)) {
		fstream buyB;
		buyB.open("BuyOrder.txt");
		if (!buyB)
			cout << "fail to open buyBook";
		buyB << fixMap[orderId] << "\t\t"
			<< fixMap[shareName] << "\t\t" << fixMap[orderQty] << "\t\t"
			<< fixMap[price] << "\t\t" << fixMap[getLeft] << "\t\t"
			<< fixMap[time] << "\n";
		buyB.close();
	}
	else if (fixMap[side] == (sell)) {
		fstream sellB;
		sellB.open("SellOrder.txt");
		if (!sellB)
			cout << "fail to open sellBook";
		sellB << fixMap[orderId] << "\t\t"
			<< fixMap[shareName] << "\t\t" << fixMap[orderQty] << "\t\t"
			<< fixMap[price] << "\t\t" << fixMap[getLeft] << "\t\t"
			<< fixMap[time] << "\n";
		sellB.close();
	}
	else
		whether_valid = false;
}

